const express = require('express');
const router = express.Router();
const { passport, isAuthenticated } = require('../config/oauth');

// Login page
router.get('/login', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Login</title>
      <style>
        body { font-family: Arial, sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-container { text-align: center; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .login-button { padding: 10px 20px; background-color: #4285F4; color: white; border: none; border-radius: 4px; cursor: pointer; }
      </style>
    </head>
    <body>
      <div class="login-container">
        <h2>Login to Comercio API</h2>
        <p>Click the button below to login with Google:</p>
        <a href="/auth/google"><button class="login-button">Login with Google</button></a>
      </div>
    </body>
    </html>
  `);
});

// Google OAuth routes
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

router.get('/google/callback', 
  passport.authenticate('google', { failureRedirect: '/auth/login' }),
  (req, res) => {
    // Set JWT token in cookie
    res.cookie('jwt', req.user.token, { 
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production'
    });
    
    // Redirect to Swagger docs
    res.redirect('/docs');
  }
);

// Logout route
router.get('/logout', (req, res) => {
  req.logout(() => {
    res.clearCookie('jwt');
    res.redirect('/auth/login');
  });
});

// API token endpoint (for Swagger Auth)
router.get('/token', isAuthenticated, (req, res) => {
  res.json({ token: req.user.token });
});

module.exports = router;