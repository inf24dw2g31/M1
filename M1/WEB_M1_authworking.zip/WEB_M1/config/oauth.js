const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mysql = require('mysql2/promise');
const jwt = require('jsonwebtoken');

// Create the same connection pool used in services
const pool = mysql.createPool({
  host: process.env.DATABASE_HOST || 'database',
  user: process.env.DATABASE_USER || 'dev_user',
  password: process.env.DATABASE_PASSWORD || 'dev_password',
  database: process.env.DATABASE_NAME || 'comerciodev',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// JWT Secret
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_key';

// Initialize Google strategy
passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/auth/google/callback',
    scope: ['profile', 'email']
  },
  async function(accessToken, refreshToken, profile, done) {
    try {
      // Check if user exists in database
      const [rows] = await pool.query('SELECT * FROM utilizador WHERE email = ?', [profile.emails[0].value]);
      
      let user;
      
      if (rows.length === 0) {
        // Create new user if not exists
        const [result] = await pool.query(
          'INSERT INTO utilizador (nome, email, senha, tipo_utilizador) VALUES (?, ?, ?, ?)',
          [profile.displayName, profile.emails[0].value, 'google-auth', 'cliente']
        );
        
        user = {
          id: result.insertId,
          nome: profile.displayName,
          email: profile.emails[0].value,
          tipo_utilizador: 'cliente'
        };
      } else {
        user = rows[0];
      }
      
      // Check if user is admin
      const [adminRows] = await pool.query('SELECT * FROM administrador WHERE id_utilizador = ?', [user.id]);
      user.isAdmin = adminRows.length > 0;
      
      // Create JWT token
      const token = jwt.sign(
        { id: user.id, email: user.email, tipo: user.tipo_utilizador, isAdmin: user.isAdmin },
        JWT_SECRET,
        { expiresIn: '1h' }
      );
      
      user.token = token;
      return done(null, user);
    } catch (error) {
      console.error('Error in Google auth:', error);
      return done(error, null);
    }
  }
));

// Serialize user into session
passport.serializeUser((user, done) => {
  done(null, user);
});

// Deserialize user from session
passport.deserializeUser((user, done) => {
  done(null, user);
});

// Middleware to check if user is authenticated
const isAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    // Log the authenticated user details
    console.log(`Authenticated user: ${req.user.email} (${req.user.id})`);
    return next();
  }
  res.redirect('/auth/login');
};

// JWT Validation middleware
const validateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: No token provided' });
  }
  
  const token = authHeader.split(' ')[1];
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    // Log the authenticated user details
    console.log(`JWT authenticated user: ${req.user.email} (${req.user.id})`);
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};

module.exports = {
  passport,
  isAuthenticated,
  validateJWT,
  JWT_SECRET
};