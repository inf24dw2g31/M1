'use strict';

require('dotenv').config();
var path = require('path');
var http = require('http');
var express = require('express');
var session = require('express-session');
var cookieParser = require('cookie-parser');
var oas3Tools = require('oas3-tools');
const { passport, validateJWT } = require('./config/oauth');
const authRoutes = require('./routes/auth');

var serverPort = process.env.PORT || 3000; // Uses the PORT environment variable

// Create Express app
var app = express();

// Cookie and session middleware
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'session_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));

// Initialize Passport
app.use(passport.initialize());
app.use(passport.session());

// Auth routes
app.use('/auth', authRoutes);

// Default route redirects to login or docs
app.get('/', (req, res) => {
  if (req.isAuthenticated()) {
    res.redirect('/docs');
  } else {
    res.redirect('/auth/login');
  }
});

// swaggerRouter configuration
var options = {
  routing: {
    controllers: path.join(__dirname, './controllers')
  },
};

var expressAppConfig = oas3Tools.expressAppConfig(path.join(__dirname, 'api/openapi.yaml'), options);
var oasApp = expressAppConfig.getApp();

// Add JWT validation middleware to API routes
app.use('/api', (req, res, next) => {
  const isSecuredPath = req.path.includes('/utilizadores/') || 
                        req.path.includes('/administradores/') || 
                        req.path.includes('/categorias/') || 
                        req.path.includes('/produtos/') || 
                        req.path.includes('/pedidos/');
                        
  const isSecuredMethod = ['POST', 'PUT', 'DELETE'].includes(req.method);
  
  if (isSecuredPath && isSecuredMethod) {
    return validateJWT(req, res, next);
  }
  next();
}, oasApp);

// Use swagger docs from oas3-tools
app.use(oasApp);

// Initialize the Swagger middleware
http.createServer(app).listen(serverPort, function () {
 // console.log('Your server is listening on port %d (http://localhost:%d)', serverPort, serverPort);
 // console.log('Swagger-ui is available on http://localhost:%d/docs', serverPort);
  console.log('Authentication is available on http://localhost:%d/auth/login', serverPort);
});